/*__global__ void kernel( unsigned int, unsigned int, int, int, unsigned char*, unsigned char*,float*);

*/
__global__void kernel(unsigned int, unsigned int , float *, float *,float *);